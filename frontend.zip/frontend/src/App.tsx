import './App.css'
import Dashboard from './pages/Dashboard'
import Sidebar from './components/Sidebar'

function App() {

  return (
    <div className='app'>
      
    </div>
  )
}

export default App
