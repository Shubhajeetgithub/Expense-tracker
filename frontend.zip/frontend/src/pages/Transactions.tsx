import React from 'react'

function Transactions() {
  return (
    <div>
        <h1>Transactions</h1>
        <p>Page under construction</p>
    </div>
  )
}

export default Transactions
